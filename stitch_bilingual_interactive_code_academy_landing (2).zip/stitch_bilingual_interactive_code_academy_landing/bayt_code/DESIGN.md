---
name: Bayt Code
colors:
  surface: '#061423'
  surface-dim: '#061423'
  surface-bright: '#2d3a4a'
  surface-container-lowest: '#020f1e'
  surface-container-low: '#0f1c2c'
  surface-container: '#132030'
  surface-container-high: '#1e2b3b'
  surface-container-highest: '#283646'
  on-surface: '#d6e4f9'
  on-surface-variant: '#d6c4b0'
  inverse-surface: '#d6e4f9'
  inverse-on-surface: '#243141'
  outline: '#9e8e7c'
  outline-variant: '#514536'
  surface-tint: '#ffb956'
  primary: '#ffc16c'
  on-primary: '#462b00'
  primary-container: '#e8a33d'
  on-primary-container: '#5f3c00'
  inverse-primary: '#835400'
  secondary: '#aac9f1'
  on-secondary: '#0e3252'
  secondary-container: '#2b4b6c'
  on-secondary-container: '#9cbbe2'
  tertiary: '#99d3ff'
  on-tertiary: '#00344e'
  tertiary-container: '#63b9f3'
  on-tertiary-container: '#00486a'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffddb5'
  primary-fixed-dim: '#ffb956'
  on-primary-fixed: '#2a1800'
  on-primary-fixed-variant: '#643f00'
  secondary-fixed: '#d1e4ff'
  secondary-fixed-dim: '#aac9f1'
  on-secondary-fixed: '#001d36'
  on-secondary-fixed-variant: '#29496a'
  tertiary-fixed: '#c9e6ff'
  tertiary-fixed-dim: '#8bceff'
  on-tertiary-fixed: '#001e2f'
  on-tertiary-fixed-variant: '#004b6f'
  background: '#061423'
  on-background: '#d6e4f9'
  surface-variant: '#283646'
typography:
  display-hero:
    fontFamily: Inter
    fontSize: 3rem
    fontWeight: '700'
    lineHeight: 3.5rem
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Inter
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 2.75rem
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Inter
    fontSize: 2rem
    fontWeight: '600'
    lineHeight: 2.5rem
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
  headline-md:
    fontFamily: Inter
    fontSize: 1.375rem
    fontWeight: '600'
    lineHeight: 1.875rem
  headline-sm:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.625rem
  body-lg:
    fontFamily: Inter
    fontSize: 1.0625rem
    fontWeight: '400'
    lineHeight: 1.75rem
  body-md:
    fontFamily: Inter
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: 1.6rem
  body-sm:
    fontFamily: Inter
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.375rem
  label-md:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '500'
    lineHeight: 1.25rem
  label-sm:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: 1rem
    letterSpacing: 0.02em
  code-inline:
    fontFamily: monospace
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.25rem
  code-block:
    fontFamily: monospace
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.5rem
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-lg: 1.5rem
  margin: 1rem
  margin-md: 1.5rem
  margin-lg: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.875rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style

This design system delivers a calm, distraction-free, and high-legibility developer environment tailored for Arabic-speaking learners and bilingual technical workflows. Drawing from developer tool aesthetics and purposeful minimalism, it prioritizes optical clarity, low eye strain during prolonged screen sessions, and instant structural legibility across script directions.

The personality balances utilitarian technical precision with an inviting, accessible warmth. Amber accents act as an intellectual beacon—guiding attention toward active code execution states, primary milestones, and interactive sandboxes without inducing cognitive fatigue. Deep navy and slate surfaces create an immersive nocturnal workspace.

Interactive code sandboxes, interactive documentation, and bilingual technical glossaries maintain visual symmetry. Cultural and structural accommodation is paramount: the interface natively supports bidirectional context switching, allowing fluid shifts between Arabic (RTL) narrative instruction and strictly left-to-right (LTR) syntax trees, execution terminals, and code editors.

## Colors

The palette relies on a disciplined dark scheme constructed to prevent fatigue while sustaining AA/AAA accessibility compliance across all interactive elements.

### Surface System
- **Base Canvas (`#0d1b2a`):** Deep abyssal navy serving as the foundational background.
- **Code Panel Canvas (`#0a1520`):** Ultra-dark, high-contrast recessed ground for the code editor, terminal, and interactive REPL outputs.
- **Primary Surface / Cards (`#142a3f`):** Elevated container layer used for lesson panels, instruction modules, and challenge cards.
- **Secondary Surface (`#1b3550`):** Interactive card headers, hover states, sub-navigation, and docked toolbars.
- **Structural Outlines (`#274768`):** 1px delineations between editor panes, split-screens, and navigation panels.

### Accent & Typography
- **Brand Amber (`#e8a33d`):** Primary highlight for call-to-actions, active progress nodes, step markers, and run triggers. When applied as a solid fill, foreground typography always switches to `#0d1b2a` for stark, crisp optical contrast.
- **Primary Text (`#eaf1f8`):** Clean, crisp, desaturated off-white ensuring maximum readability without the glare of pure `#ffffff`.
- **Muted / Dim Text (`#93a8bf`):** Balanced cool slate for secondary metadata, breadcrumbs, placeholder text, and inactive tab labels.

### Feedback System
- **Success (`#4ade80`):** Vibrant mint-emerald for passing test suites, correct code submissions, and system readiness.
- **Error (`#f87171`):** High-visibility coral-crimson for syntax exceptions, failed test assertions, and validation alerts.
- **Warning (`#fbbf24`):** Soft amber-yellow for non-breaking deprecation notices and resource warnings.

## Typography

Typography bridges technical rigor and educational comfort. The interface utilizes a dual-engine typographic framework:

1. **System Primary Font (Inter):** Deployed for UI controls, navigation, English instructions, and system meta-labels. It delivers clean glyph rendering and high vertical metric alignment.
2. **Arabic Companion Pair (Tajawal):** Implemented wherever Arabic strings occur (`:lang(ar)`). Its geometric yet humanist proportions mirror the x-height and optical density of Inter, preventing visual stutter or layout jumping across language toggles.
3. **Monospace Standard (Fira Code / System Monospace):** Reserved strictly for code editors, inline snippets, console streams, and terminal traces. Ligatures clarify operators (`=>`, `===`, `!=`), accelerating cognitive code comprehension.

### Bidirectional Layout Rules
- Body text, documentation, and conceptual explanations flow according to the active locale (`dir="rtl"` for Arabic, `dir="ltr"` for English).
- Code snippets, code blocks, terminal tabs, and directory trees remain permanently pinned to `direction: ltr` with `text-align: left`, irrespective of document language, respecting global programming conventions.

## Layout & Spacing

This design system employs an adaptive fluid-split layout designed for code-along education:

### Layout Structures
- **Split Workspace (Desktop):** A dual-pane or tri-pane viewport (Lesson Content / Code Editor / Interactive Output). Panes are separated by precise 1px borders (`#274768`) and can be resized horizontally.
- **Column Grids:** An asymmetric 12-column layout handles dashboards, course catalogs, and documentation overviews with flexible gutters (`gutter-lg: 1.5rem`).
- **Responsive Stacking:** On viewports under `1024px`, the split-pane switches to a tabbed workbench (Instruction | Editor | Console) to ensure input targets stay comfortable on mobile screens.

### Logical Properties
All padding, margin, and position coordinates must be authored with CSS Logical Properties (`padding-inline-start`, `margin-inline-end`) rather than physical directions (`left`/`right`) to ensure flawless bidirectional mirroring between Arabic and English contexts without code duplication.

## Elevation & Depth

To preserve the utilitarian focus of an integrated development environment, this design system avoids heavy drop shadows and ornamental diffusion. Visual hierarchy is established through **tonal layering and low-contrast outlines**:

1. **Layer 0 (Canvas):** `#0d1b2a` forms the furthest recessed ground.
2. **Layer 1 (Card/Container Surfaces):** `#142a3f` provides elevated planes for reading and writing, bounded by a uniform 1px border of `#274768`.
3. **Layer 2 (Interactive Floating Surfaces & Flyouts):** Modals, dropdowns, and contextual auto-complete tooltips adopt `#1b3550` with an ambient edge shadow: `0 8px 24px -4px rgba(5, 11, 18, 0.6)`.
4. **Active Focus & Code Selection:** Highlighting uses an amber-tinted glow outline (`0 0 0 2px rgba(232, 163, 61, 0.45)`) rather than diffuse drop shadows, retaining crisp edges across all panels.

## Shapes

The shape system is set to Level 2 (Rounded), introducing controlled 14px outer contours on core structural components to counter cold, clinical industrialism while preserving structural discipline.

- **Cards & Major Panels:** `rounded-lg` (14px / ~0.875rem - 1rem) for lesson containers, code shells, and modal dialogs.
- **Controls & Form Elements:** Standard `rounded` (0.5rem / 8px) for buttons, inputs, interactive chips, and code tabs.
- **Micro Elements:** `space-xs` to `space-sm` (4px) on badges, syntax tags, and scrollbar thumbs.
- **Code Viewport:** The internal editor pane maintains flush, squared inner corners within rounded card envelopes to emulate professional development tooling.

## Components

### Buttons
- **Primary Action (Run Code, Submit Milestone):** Solid `#e8a33d` background, `#0d1b2a` text weight 600. On hover: lightness elevates to `#f2b254`. On active: subtle scale shift (0.98).
- **Secondary Action (Reset, Next Lesson):** `#1b3550` background, `#eaf1f8` text, 1px border in `#274768`. On hover: surface transitions to `#234364`.
- **Ghost/Tertiary (Copy Code, Docs Link):** Transparent background, `#93a8bf` text. On hover: `#142a3f` background and `#eaf1f8` text.

### Interactive Code Editor & Output Pane
- **Container:** Grounded in `#0a1520` with a 1px `#274768` border and 14px outer radius.
- **Editor Header Toolbar:** `#142a3f` background, containing file tabs, language badge (`JavaScript`, `Python`), and the Run button.
- **Code Area:** Permanently LTR. Monospace typography with 1.5 line height for comfortable code scanning. Line numbers styled in `#93a8bf` with 40% opacity.
- **Terminal Output:** Recessed terminal drawer at `#081018`, supporting split terminal status outputs with `#4ade80` (stdout) and `#f87171` (stderr).

### Input Fields & Controls
- **Text Inputs:** Background `#0d1b2a`, border 1px `#274768`, text `#eaf1f8`, corner radius 8px. Focus indicator: border `#e8a33d` with an ambient amber focus halo.
- **Checkboxes & Radios:** 20px base dimensions. Unchecked: `#142a3f` with `#274768` border. Checked: solid `#e8a33d` fill with `#0d1b2a` icon tick.

### Cards & Lesson Nodes
- **Lesson Content Card:** `#142a3f` background, 14px border radius, 1px `#274768` border. Header section separated by an internal 1px horizontal rule.
- **Progress Trackers:** Horizontal or vertical path with steps outlined in `#274768`. Completed steps marked by `#4ade80` nodes; active steps feature glowing `#e8a33d` indicators.

### Bilingual Chips & Status Badges
- **Status Badges:** Compact pills with `0.75rem` typography.
  - Progress: Soft amber tint (`background: rgba(232, 163, 61, 0.12)`, `color: #e8a33d`).
  - Solved: Emerald tint (`background: rgba(74, 222, 128, 0.12)`, `color: #4ade80`).
- **Language Switcher Control:** Segmented toggle pill (`عربي` | `EN`) located in the primary navigation, providing immediate locale re-orientation and bidirectional flipping across the document root.